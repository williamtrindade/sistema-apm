-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: mysql669.umbler.com    Database: db_apm
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_apm`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_apm` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_apm`;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci,
  `owner_album_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
INSERT INTO `albums` VALUES (1,'Aquisições APM - Primeiro Ano de Gestão',0,'<p><br></p>',NULL,'2019-08-05 22:57:30','2019-08-05 22:57:30'),(2,'Fotos',1,'<p><br></p>',1,'2019-08-05 22:59:23','2019-08-05 22:59:23'),(3,'Atividades em 2015',0,'<p><br></p>',NULL,'2019-08-07 16:05:21','2019-08-07 16:05:21'),(4,'Chá das Mães 2015',1,'<p><br></p>',3,'2019-08-07 16:05:42','2019-08-07 16:05:42'),(5,'Concurso \"Fazendo arte no Geogebra\"',1,'<p><br></p>',3,'2019-08-07 16:05:59','2019-08-07 16:05:59'),(6,'Entregas de faixas e crachás - DTG',1,'<p><br></p>',3,'2019-08-07 16:06:14','2019-08-07 16:06:14'),(7,'II Encontro da Primavera - 25 OUT 15',1,'<p class=\"ql-align-justify\">No dia 25 de outubro de 2015, na sede dos Funcionários da Caixa Econômica Federal, ocorreu o II Encontro da Primavera, promovido pela Associação de Pais e Mestres do CMSM.</p><p class=\"ql-align-justify\">A atividade contou com a presença de alunos, familiares, militares e visitantes, que durante a tarde e noite puderam desfrutar das atividades previstas; como brincadeiras, mateada, brinquedos infláveis, cama elástica, Show com Ricardo Barros, Banda Sanfona, Mateus e Banda, além de outras várias apresentações artísticas, palhaço Biscoitão, Animador Paulo Oliveira, pintura artística, distribuição gratuita de algodão doce, picolés, carrapinha, refrigerantes.</p><p class=\"ql-align-justify\">O evento contou com apoio do Lojão Total, Pratiki Esporte, Vencal Calçados, Renni Farmácias, POUPEX, SUPERAUTO, Cuias Fracari, Magazine Luiza, SM Loja Militar, Lojas Eny, Canto Militar, Casa Dos Militares, Paraiso Infantil e a própria APM, que conjuntas distribuíram mais de 500 prêmios aos participantes, dentre eles uma bicicleta.</p><p><br></p>',3,'2019-08-07 16:06:25','2019-08-07 16:17:27'),(8,'Prêmios concurso Literário',1,'<p><br></p>',3,'2019-08-07 16:06:34','2019-08-07 16:06:34'),(9,'Prestação de contas - 09 JUN 15',1,'<p class=\"ql-align-justify\"><strong>2ª ASSEMBLEIA GERAL 2015</strong></p><p class=\"ql-align-justify\"><strong><span class=\"ql-cursor\">﻿</span></strong></p><p class=\"ql-align-justify\">No dia 9 de junho, foi realizada a segunda Assembleia Geral do corrente ano, no Refeitório dos Alunos e no Cassino dos Of/ST e Sgt do Colégio Militar de Santa Maria (CMSM). Na ocasião foram abordados os seguintes assuntos:</p><p class=\"ql-align-justify\">- Prestação de contas anual;</p><p class=\"ql-align-justify\">- II Encontro da Primavera;</p><p class=\"ql-align-justify\">- Confecção das Agendas 2016; e</p><p class=\"ql-align-justify\">- Anuário 2015.</p><p class=\"ql-align-justify\">A reunião contou com a ilustre presença do Gen Bda FÁBIO BENVENUTTI <strong>CASTRO</strong>, Comandante da 6ª Bda Inf Bld e de sua digníssima esposa Sra Helena Castro.</p><p class=\"ql-align-justify\">Após foi servida uma feijoada para aproximadamente 450 pessoas, além de cachorro quente e bombons para 150 crianças. Em seguida foi servido bolo comemorativo alusivo a um ano de gestão da nova diretoria. Também contou com o show do cantor Ricardo Barros.</p><p><br></p>',3,'2019-08-07 16:06:44','2019-08-07 16:20:54'),(10,'Prestação de contas - 12 MAR 15',1,'<p><br></p>',3,'2019-08-07 16:07:00','2019-08-07 16:07:00'),(11,'Prestação de contas - 13 NOV 15',1,'<p class=\"ql-align-justify\"><strong>4ª ASSEMBLEIA GERAL 2015</strong></p><p class=\"ql-align-justify\"><strong><span class=\"ql-cursor\">﻿</span></strong></p><p class=\"ql-align-justify\">No dia 13 de novembro, foi realizada a quarta Assembleia Geral do corrente ano, no Centro de Eventos do Colégio Militar de Santa Maria (CMSM). Na ocasião foi realizada a prestação de contas de encerramento do ano, bem como a homenagem ao Cel Ricardo e sua digníssima esposa Sra Paula.</p><p class=\"ql-align-justify\">Após foi oferecido um coquetel para aproximadamente 350 pessoas, com a animação de show ao vivo com Mateus e Banda.</p><p><br></p>',3,'2019-08-07 16:07:17','2019-08-07 16:41:51'),(12,'Prestação de contas - 26 AGO 15',1,'<p><br></p>',3,'2019-08-07 16:07:43','2019-08-07 16:07:43'),(13,'VIII Encontro das APM - 24​​​​​​​​​​​​​​​​​​ SET 15 (Belo Horizonte - MG)',1,'<h3>VIII Encontro das APM - 24​​​​​​​​​​​​​​​​​​ SET 15 (Belo Horizonte - MG)</h3><p class=\"ql-align-justify\"><br></p><p class=\"ql-align-justify\">Associação de Pais e Mestres do CMBH sediou no período de 24 a 26 de setembro de 2015, o VIII Encontro das APM do Sistema Colégio Militar do Brasil.</p><p class=\"ql-align-justify\">Oportunidade esta que serviu para o intercâmbio de ideias que vem sendo bem sucedidas no âmbito das APM, bem como apresentação do Projeto Educação Inclusiva e Acessibilidade.</p><p class=\"ql-align-justify\">Como parte integrante da programação, no dia 26 fomos brindados com um belíssimo passeio até a cidade de Ouro Preto, onde pudemos ter aulas de História ao ar livre por conta de sua vasta arquitetura colonial e gastronomia local.</p><p class=\"ql-align-justify\"><br></p><p class=\"ql-align-justify\">A APM/CMSM esteve representada na pessoa do seu Presidente (ST Pinho), do 1º Tesoureiro (3º Sgt Cunha) e do Coordenador-Ligação (1º Sgt Valdomiro).</p><p class=\"ql-align-justify\">Nesta oportunidade reiteramos a receptividade hospitaleira e o convívio salutar que fomos alvos por parte de todos os integrantes da APM/CMBH, Formulamos na pessoa de sua Presidente, a Sra Janine Matoso de Medeiros Toledo e sua equipe votos de gratidão e sucesso nas empreitadas vindouras.</p><p class=\"ql-align-justify\"><br></p><p>Imagens: ST Pinho – Presidente da APM/CMSM</p>',3,'2019-08-07 16:07:56','2019-08-07 16:45:30'),(14,'Aquisições APM - Segundo Ano de Gestão',0,'<p><br></p>',NULL,'2019-08-07 16:46:16','2019-08-07 16:46:16'),(15,'Fotos',1,'<p><br></p>',14,'2019-08-07 16:49:17','2019-08-07 16:49:17'),(16,'Aquisições APM - Terceiro Ano de Gestão',0,'<p><br></p>',NULL,'2019-08-07 16:50:54','2019-08-07 16:50:54'),(17,'Fotos',1,'<p><br></p>',16,'2019-08-07 16:51:56','2019-08-07 16:51:56'),(18,'Instalações APM',0,'<p><br></p>',NULL,'2019-08-07 16:52:44','2019-08-07 16:52:44'),(19,'Foto',1,'<p><br></p>',18,'2019-08-07 16:52:55','2019-08-07 16:52:55'),(20,'Atividades em 2016',0,'<p><br></p>',NULL,'2019-08-07 16:53:39','2019-08-07 16:53:39'),(21,'Trabalho Voluntário',1,'<p><br></p>',20,'2019-08-07 16:54:09','2019-08-07 16:54:09'),(22,'Costelaço do Vagão - 14 MAIO 16',1,'<p class=\"ql-align-justify\">No último sábado 14 de maio às 9h, foi realizada uma reunião de prestação de contas dos meses de Março/Abril e a Confraternização Alusiva ao dia da Cavalaria denominada “Costelaço do Vagão”, no Centro Hípico junto ao Campo de Instrução de Santa Maria (CISM). Na ocasião houve as seguintes atividades: passeio a cavalo (9h às 10h), 3ª Etapa da Prova de Melhor Cavalheiro (10h às 12h), prestação de Contas (12h30min) e um saboroso Costelão que foi servido à partir dás 13hs.</p><p class=\"ql-align-justify\"><br></p><p class=\"ql-align-justify\">Após o almoço servido para aproximadamente 400 pessoas, foram sorteados vários brindes, apresentações musicais. Durante as atividades foi distribuída erva mate e água quente.</p><p><br></p>',20,'2019-08-07 16:54:26','2019-08-07 17:00:20'),(23,'Assembleia Geral 11 AGO 16',1,'<p><br></p>',20,'2019-08-07 16:54:46','2019-08-07 16:54:46'),(24,'Assembleia Geral 15 MAR 16',1,'<p><br></p>',20,'2019-08-07 16:55:06','2019-08-07 16:55:06'),(25,'III Encontro da Primavera',1,'<p><br></p>',20,'2019-08-07 16:55:19','2019-08-07 16:55:19');
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos`
--

DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avisos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo` longtext COLLATE utf8mb4_unicode_ci,
  `pdf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos`
--

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
INSERT INTO `avisos` VALUES (2,'ASSEMBLEIA GERAL - 22 AGO 19 - 18h em Primeira Chamada','<p><br></p>','2019-08-05 19:52:55.pdf','2019-08-05 22:52:55','2019-08-05 22:52:55');
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contas`
--

DROP TABLE IF EXISTS `contas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `arquivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contas`
--

LOCK TABLES `contas` WRITE;
/*!40000 ALTER TABLE `contas` DISABLE KEYS */;
INSERT INTO `contas` VALUES (1,'2019-08-05 19:45:08.pdf','2014-07-05','2019-08-05 22:45:08','2019-08-05 22:45:08'),(2,'2019-08-05 19:45:56.pdf','2014-08-05','2019-08-05 22:45:56','2019-08-05 22:45:56'),(3,'2019-08-05 19:46:18.pdf','2014-09-05','2019-08-05 22:46:18','2019-08-05 22:46:18'),(4,'2019-08-05 19:46:38.pdf','2014-10-05','2019-08-05 22:46:38','2019-08-05 22:46:38'),(5,'2019-08-05 19:47:27.pdf','2014-12-05','2019-08-05 22:47:27','2019-08-05 22:47:27'),(6,'2019-08-05 19:47:46.pdf','2014-11-05','2019-08-05 22:47:46','2019-08-05 22:47:46'),(7,'2019-08-05 19:48:26.pdf','2015-01-05','2019-08-05 22:48:26','2019-08-05 22:48:26'),(8,'2019-08-05 21:04:50.pdf','2015-02-05','2019-08-06 00:04:50','2019-08-06 00:04:50'),(9,'2019-08-05 21:05:09.pdf','2015-03-05','2019-08-06 00:05:09','2019-08-06 00:05:09'),(10,'2019-08-05 21:05:24.pdf','2015-04-05','2019-08-06 00:05:24','2019-08-06 00:05:24'),(11,'2019-08-05 21:05:44.pdf','2015-05-05','2019-08-06 00:05:44','2019-08-06 00:05:44'),(12,'2019-08-05 21:06:00.pdf','2015-06-05','2019-08-06 00:06:00','2019-08-06 00:06:00'),(13,'2019-08-05 21:06:17.pdf','2015-07-05','2019-08-06 00:06:17','2019-08-06 00:06:17'),(14,'2019-08-05 21:06:32.pdf','2015-08-05','2019-08-06 00:06:32','2019-08-06 00:06:32'),(15,'2019-08-05 21:06:50.pdf','2015-09-05','2019-08-06 00:06:50','2019-08-06 00:06:50'),(16,'2019-08-05 21:07:07.pdf','2015-10-05','2019-08-06 00:07:07','2019-08-06 00:07:07'),(18,'2019-08-07 11:07:24.pdf','2017-04-05','2019-08-07 14:07:24','2019-08-07 14:07:24'),(19,'2019-08-07 11:18:40.pdf','2016-01-05','2019-08-07 14:18:40','2019-08-07 14:18:40'),(20,'2019-08-07 11:20:34.pdf','2016-01-05','2019-08-07 14:20:34','2019-08-07 14:20:34'),(21,'2019-08-07 11:20:47.pdf','2016-03-05','2019-08-07 14:20:47','2019-08-07 14:20:47'),(22,'2019-08-07 11:21:00.pdf','2016-04-05','2019-08-07 14:21:00','2019-08-07 14:21:00'),(23,'2019-08-07 11:21:11.pdf','2016-05-05','2019-08-07 14:21:11','2019-08-07 14:21:11'),(24,'2019-08-07 11:21:22.pdf','2016-06-05','2019-08-07 14:21:22','2019-08-07 14:21:22'),(25,'2019-08-07 11:21:34.pdf','2016-07-05','2019-08-07 14:21:34','2019-08-07 14:21:34'),(26,'2019-08-07 11:21:45.pdf','2016-08-05','2019-08-07 14:21:45','2019-08-07 14:21:45'),(27,'2019-08-07 11:22:00.pdf','2016-09-05','2019-08-07 14:22:00','2019-08-07 14:22:00'),(28,'2019-08-07 11:22:12.pdf','2016-10-05','2019-08-07 14:22:12','2019-08-07 14:22:12'),(29,'2019-08-07 11:22:24.pdf','2016-11-05','2019-08-07 14:22:24','2019-08-07 14:22:24'),(31,'2019-08-07 11:24:19.pdf','2016-02-05','2019-08-07 14:24:19','2019-08-07 14:24:19'),(32,'2019-08-07 11:24:31.pdf','2016-12-05','2019-08-07 14:24:31','2019-08-07 14:24:31'),(33,'2019-08-07 11:25:23.pdf','2015-11-05','2019-08-07 14:25:23','2019-08-07 14:25:23'),(34,'2019-08-07 11:25:35.pdf','2016-12-05','2019-08-07 14:25:35','2019-08-07 14:25:35'),(35,'2019-08-07 11:26:13.pdf','2015-12-05','2019-08-07 14:26:13','2019-08-07 14:26:13'),(36,'2019-08-07 11:29:47.pdf','2017-01-05','2019-08-07 14:29:47','2019-08-07 14:29:47'),(37,'2019-08-07 11:29:59.pdf','2017-02-05','2019-08-07 14:29:59','2019-08-07 14:29:59'),(38,'2019-08-07 11:30:11.pdf','2017-03-05','2019-08-07 14:30:11','2019-08-07 14:30:11'),(39,'2019-08-07 11:30:22.pdf','2017-04-05','2019-08-07 14:30:22','2019-08-07 14:30:22'),(40,'2019-08-07 11:30:33.pdf','2017-05-05','2019-08-07 14:30:33','2019-08-07 14:30:33'),(41,'2019-08-07 11:30:43.pdf','2017-06-05','2019-08-07 14:30:43','2019-08-07 14:30:43'),(42,'2019-08-07 11:30:53.pdf','2017-07-05','2019-08-07 14:30:53','2019-08-07 14:30:53'),(43,'2019-08-07 11:31:06.pdf','2017-08-05','2019-08-07 14:31:06','2019-08-07 14:31:06'),(44,'2019-08-07 11:31:17.pdf','2017-09-05','2019-08-07 14:31:17','2019-08-07 14:31:17'),(45,'2019-08-07 11:31:45.pdf','2017-10-05','2019-08-07 14:31:45','2019-08-07 14:31:45'),(46,'2019-08-07 11:31:57.pdf','2017-11-05','2019-08-07 14:31:57','2019-08-07 14:31:57'),(47,'2019-08-07 11:32:07.pdf','2017-12-05','2019-08-07 14:32:07','2019-08-07 14:32:07'),(48,'2019-08-07 11:34:14.pdf','2018-01-05','2019-08-07 14:34:14','2019-08-07 14:34:14'),(49,'2019-08-07 11:34:23.pdf','2018-02-05','2019-08-07 14:34:23','2019-08-07 14:34:23'),(50,'2019-08-07 11:34:34.pdf','2018-03-05','2019-08-07 14:34:34','2019-08-07 14:34:34'),(51,'2019-08-07 11:34:43.pdf','2018-04-05','2019-08-07 14:34:43','2019-08-07 14:34:43'),(52,'2019-08-07 11:34:53.pdf','2018-05-05','2019-08-07 14:34:53','2019-08-07 14:34:53'),(53,'2019-08-07 11:35:03.pdf','2018-06-05','2019-08-07 14:35:03','2019-08-07 14:35:03'),(54,'2019-08-07 11:35:13.pdf','2018-07-05','2019-08-07 14:35:13','2019-08-07 14:35:13'),(55,'2019-08-07 11:35:24.pdf','2018-08-05','2019-08-07 14:35:24','2019-08-07 14:35:24'),(56,'2019-08-07 11:35:36.pdf','2018-10-02','2019-08-07 14:35:36','2019-08-07 14:35:36'),(57,'2019-08-07 11:35:45.pdf','2018-11-05','2019-08-07 14:35:45','2019-08-07 14:35:45'),(58,'2019-08-07 11:41:42.pdf','2018-09-05','2019-08-07 14:41:42','2019-08-07 14:41:42'),(59,'2019-08-07 11:52:48.pdf','2018-12-05','2019-08-07 14:52:48','2019-08-07 14:52:48'),(60,'2019-08-07 11:53:02.pdf','2019-01-05','2019-08-07 14:53:02','2019-08-07 14:53:02'),(61,'2019-08-07 11:53:12.pdf','2019-02-05','2019-08-07 14:53:12','2019-08-07 14:53:12'),(62,'2019-08-07 11:53:24.pdf','2019-03-05','2019-08-07 14:53:24','2019-08-07 14:53:24'),(63,'2019-08-07 11:53:34.pdf','2019-04-05','2019-08-07 14:53:34','2019-08-07 14:53:34'),(64,'2019-08-07 11:53:45.pdf','2019-05-05','2019-08-07 14:53:45','2019-08-07 14:53:45'),(65,'2019-08-07 11:53:55.pdf','2019-06-05','2019-08-07 14:53:55','2019-08-07 14:53:55'),(66,'2019-08-07 11:54:05.pdf','2019-07-05','2019-08-07 14:54:05','2019-08-07 14:54:05');
/*!40000 ALTER TABLE `contas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagems`
--

DROP TABLE IF EXISTS `imagems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagems` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `imagem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `album_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagems`
--

LOCK TABLES `imagems` WRITE;
/*!40000 ALTER TABLE `imagems` DISABLE KEYS */;
INSERT INTO `imagems` VALUES (1,'phoca_thumb_m_agendas.jpg2019-08-05 20:02:11jpeg',2,'2019-08-05 23:02:11','2019-08-05 23:02:11'),(2,'phoca_thumb_m_agendas_distribuidas.jpg2019-08-05 20:02:11jpeg',2,'2019-08-05 23:02:11','2019-08-05 23:02:11'),(4,'alamares.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(5,'apm_repleta_de_criancas_a_sua_segunda_casa.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(6,'balas_para_distribuicao_para_os_socios_da_apm.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(7,'banner_atletismo-adquirido_em_08maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(8,'banner_clube_de_orientacao-adquirido_em_06maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(9,'banner_gremio_da_cavalaria-adquirido_em_04maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(10,'banner_gremio_da_cavalaria-adquirido_em_06maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(11,'banner_gremio_da_marinha-adquirido_em_06maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(12,'barbeador_para_ser_usado_pelos_socios_para_pequenos_retoques.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(13,'caixa_de_engraxate_com_acessorios_para_serem_usados_pelos_socios.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(14,'calcados_femininos_organizados_por_numeracao.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(15,'calcados_masculinos_organizados_por_numeracao.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(16,'camera_sony_w800-16abr15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(17,'cartao_dia_das_maes2015.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(18,'cartao_pascoa2015.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(19,'criancas_pegando_sorvetes_que_foram_distribuidos_pela-apm.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(20,'dgt1.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(21,'espelho_para_o_provador.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(22,'faixa_instalada_na_apm.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(23,'kit_chimarrao-adquirido_em_11maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(24,'livros_repassados_com_desconto_de_30_por_cento.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(25,'maes_escolhendo_uniformes.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(26,'maquina_copiadora.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(27,'maquina_copiadora02.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(28,'maquina_de_cafe-da_baristo.png2019-08-07 13:02:52png',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(29,'maquina_de_costura-dquirida_em_fev15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(30,'maquina_de_lustrar_calcados.png2019-08-07 13:02:52png',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(31,'marta_auxiliando_na_distribuicao_dos1_mil_sorvetes.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(32,'marta_e_adria-secretarias_da_apm_cmsm.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(33,'pacoas_2015-100_caixas_bombom.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(34,'pc_all_in-adquirido_em_out14.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(35,'persianas_porta_apm-adquirida_em_mar15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(36,'porta_de_vidro_da_apm.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(37,'quadro_apm-adquirido_em_20_maio15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(38,'sabonetes_distribuidos_no_dia_das_maes-maio2015.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(39,'tabua_e_ferro_de_passar_roupas_adquiridos_em_fev15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(40,'teclado.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(41,'telefone_motorola_adquirido_em_16abr15.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(42,'tv_toshiba_adquirida_em_04_abr_15_nr2.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(43,'ventilador_de_teto.jpg2019-08-07 13:02:52jpeg',2,'2019-08-07 16:02:52','2019-08-07 16:02:52'),(44,'IMG_6118.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(45,'IMG_6149.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(46,'IMG_6287.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(47,'IMG_6303.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(48,'IMG_6366.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(49,'IMG_6454.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(50,'IMG_6491.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(51,'IMG_6626.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(52,'IMG_6660.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(53,'IMG_6752.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(54,'IMG_6766.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(55,'IMG_6791.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(56,'IMG_6805.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(57,'IMG_6815.JPG2019-08-07 13:09:51jpeg',4,'2019-08-07 16:09:51','2019-08-07 16:09:51'),(58,'calculadora_2_lugar.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(59,'dsc02917.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(60,'dsc02919.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(61,'dsc02930.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(62,'pendrive_3_lugar.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(63,'tablet_1_lugar.jpg2019-08-07 13:12:14jpeg',5,'2019-08-07 16:12:14','2019-08-07 16:12:14'),(64,'4.jpg2019-08-07 13:13:38jpeg',6,'2019-08-07 16:13:38','2019-08-07 16:13:38'),(65,'5.jpg2019-08-07 13:13:38jpeg',6,'2019-08-07 16:13:38','2019-08-07 16:13:38'),(66,'brinde.jpg2019-08-07 13:13:38jpeg',6,'2019-08-07 16:13:38','2019-08-07 16:13:38'),(67,'brinde2.jpg2019-08-07 13:13:38jpeg',6,'2019-08-07 16:13:38','2019-08-07 16:13:38'),(68,'dsc_0212.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(69,'dsc_0214.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(70,'dsc_0219.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(71,'dsc_0223.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(72,'dsc_0234.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(73,'dsc_0236.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(74,'dsc_0241.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(75,'dsc_0245.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(76,'dsc_0248.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(77,'img_20151025_152916448_hdr.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(78,'img_20151025_160044050.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(79,'img_20151025_163453623.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(80,'img_20151025_191437329.jpg2019-08-07 13:16:36jpeg',7,'2019-08-07 16:16:36','2019-08-07 16:16:36'),(81,'1premio_concurso_literario.jpg2019-08-07 13:18:29jpeg',8,'2019-08-07 16:18:29','2019-08-07 16:18:29'),(82,'2premio_concurso_literario.jpg2019-08-07 13:18:29jpeg',8,'2019-08-07 16:18:29','2019-08-07 16:18:29'),(83,'3premio_concurso_literario.jpg2019-08-07 13:18:29jpeg',8,'2019-08-07 16:18:29','2019-08-07 16:18:29'),(84,'agradecimento.png2019-08-07 13:20:31png',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(85,'bolo.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(86,'bolo_apm_01anonr3.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(87,'dsc_0072.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(88,'dsc_0077.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(89,'dsc_0110.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(90,'dsc_0158.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(91,'dsc_0181.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(92,'dsc_0199.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(93,'dsc_0203.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(94,'dsc_0260.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(95,'marta_e_adria.jpg2019-08-07 13:20:31jpeg',9,'2019-08-07 16:20:31','2019-08-07 16:20:31'),(96,'apm.jpg2019-08-07 13:40:32jpeg',10,'2019-08-07 16:40:32','2019-08-07 16:40:32'),(97,'assembleia_g.jpg2019-08-07 13:40:32jpeg',10,'2019-08-07 16:40:32','2019-08-07 16:40:32'),(98,'dsc03667.jpg2019-08-07 13:41:32jpeg',11,'2019-08-07 16:41:32','2019-08-07 16:41:32'),(99,'dsc03674.jpg2019-08-07 13:41:32jpeg',11,'2019-08-07 16:41:32','2019-08-07 16:41:32'),(100,'dsc03683.jpg2019-08-07 13:41:32jpeg',11,'2019-08-07 16:41:32','2019-08-07 16:41:32'),(101,'dsc03698.jpg2019-08-07 13:41:32jpeg',11,'2019-08-07 16:41:32','2019-08-07 16:41:32'),(102,'prestacao_de_contas_apm_ago_2015.jpg2019-08-07 13:42:44jpeg',12,'2019-08-07 16:42:44','2019-08-07 16:42:44'),(103,'20150926_100520.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(104,'dsc02979.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(105,'dsc02981.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(106,'dsc02982.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(107,'dsc02985.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(108,'dsc03006.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(109,'dsc03018.jpg2019-08-07 13:44:28jpeg',13,'2019-08-07 16:44:28','2019-08-07 16:44:28'),(110,'dsc03086.jpg2019-08-07 13:44:29jpeg',13,'2019-08-07 16:44:29','2019-08-07 16:44:29'),(111,'06impressora_hp_laserjet-adquirida_em_13jun15.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(113,'08_bolsa_para_meteorologia-adquirida_em_jul_15.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(114,'09_estabilizador_nhs_ev_master_1000va-adquirido_em_17_jul_15.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(115,'54_espetos-adquiridos_em_jun15-banner.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(116,'54_ESPETOS-ADQUIRIDOS_EM_JUN15-BANNER.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(117,'140_squeeze-adquiridas_jun15-banner.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(118,'agendas_2016.png2019-08-07 13:49:36png',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(119,'baleiro-adquirido_em_jun15-banner.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(120,'cadeiras-adquirida_sem_jun15-banner.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(121,'CADEIRAS-ADQUIRIDA_SEM_JUN15-BANNER.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(122,'calculadoras.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(123,'calendario_de_mesa.jpg2019-08-07 13:49:36jpeg',15,'2019-08-07 16:49:36','2019-08-07 16:49:36'),(124,'distribuicao_de_poligrafos.png2019-08-07 13:49:37png',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(125,'hd_externo.png2019-08-07 13:49:37png',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(126,'impressora.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(127,'luzes.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(128,'medalha_de_ouro.jpg.png2019-08-07 13:49:37png',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(129,'mesadesom.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(130,'poligrafos-distribuidos_gratuitamente_para_os_socios-banner.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(131,'POLIGRAFOS-DISTRIBUIDOS_GRATUITAMENTE_PARA_OS_SOCIOS-BANNER.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(132,'recepcao_aos_alunos-03fev16.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(133,'slide1.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(134,'slide2.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(135,'slide3.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(136,'slide4.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(137,'slide5.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(138,'slide6.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(139,'slide7.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(140,'slide8.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(141,'slide9.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(142,'slide10.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(143,'slide11.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(144,'slide12.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(145,'slide13.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(146,'tablet.jpg2019-08-07 13:49:37jpeg',15,'2019-08-07 16:49:37','2019-08-07 16:49:37'),(147,'aeromodelismo.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(148,'brinde dia das mes 14 maio 2017.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(149,'carto de memria.jpg2019-08-07 13:52:08jpeg',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(150,'cheque presente aniversrio cmsm.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(151,'facas e fruteiras selene furt bombonier.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(152,'impressora epson l375.jpg2019-08-07 13:52:08jpeg',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(153,'pscoa.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(154,'roadeira.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(155,'suporte porta refrigerante.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(156,'telefone sem fio adquirido em 22 mar 17.png2019-08-07 13:52:08png',17,'2019-08-07 16:52:08','2019-08-07 16:52:08'),(157,'apm1.jpg2019-08-07 13:53:02jpeg',19,'2019-08-07 16:53:02','2019-08-07 16:53:02'),(158,'trabalho_voluntario.png2019-08-07 13:55:40png',21,'2019-08-07 16:55:40','2019-08-07 16:55:40'),(159,'slide1.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(160,'slide2.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(161,'slide3.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(162,'slide4.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(163,'slide5.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(164,'slide6.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(165,'slide7.jpg2019-08-07 13:57:22jpeg',22,'2019-08-07 16:57:22','2019-08-07 16:57:22'),(166,'slide8.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(167,'slide9.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(168,'slide10.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(169,'slide11.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(170,'slide12.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(171,'slide13.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(172,'slide14.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(173,'slide15.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(174,'slide16.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(175,'slide17.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(176,'slide18.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(177,'slide19.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23'),(178,'slide20.jpg2019-08-07 13:57:23jpeg',22,'2019-08-07 16:57:23','2019-08-07 16:57:23');
/*!40000 ALTER TABLE `imagems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_07_05_013405_create_avisos_table',1),(4,'2019_07_05_013425_create_contas_table',1),(5,'2019_07_05_013443_create_imagems_table',1),(6,'2019_07_26_125048_create_albums_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'PAULO PINHO','apmcmsm@gmail.com',NULL,'$2y$10$0rk7WBJrasnZxQ02Wf58V.Xscg8D.B35eTNw8vWOh2hSqzkr29YSS',NULL,'2019-08-05 22:38:27','2019-08-05 22:38:27'),(4,'RP','apmcmsm1@gmail.com',NULL,'$2y$10$nCYRshUXV4M1uxHRGNqkz.i9dgRugl1XRtaEHAkdDDvLKENliSzPi',NULL,'2019-08-05 22:38:27','2019-08-05 22:38:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-07 15:07:34
