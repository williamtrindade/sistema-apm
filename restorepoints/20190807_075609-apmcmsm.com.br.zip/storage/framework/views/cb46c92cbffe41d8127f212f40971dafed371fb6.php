<?php $__env->startSection('content'); ?>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<div class="container">
    <div class="columns">
        <div class="column is-12-desktop is-12-mobile">
            <h1 class="title is-4">Criação de Álbum dentro do álbum <?php echo e($album->nome); ?></h1>
            <div class="box">
                <form action="<?php echo e(route('sub-albums.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <!--NOME-->
                    <div class="form-group">
                        <label for="nome">Nome</label>
                        <input required name="nome" type="text" class="form-control" id="nome" placeholder="Digite o Nome">
                        <?php if ($errors->has('nome')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nome'); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>

                    <!-- EDITOR -->
                    <label class="label" for="editor">Descrição(Opcional)</label>
                    <div id="editor" class="field">
                        
                    </div>
                    <input required type="hidden" name="descricao" id="conteudo">                      
                    <?php if ($errors->has('descricao')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('descricao'); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    
                    <!--NIVEL-->
                    <input type="hidden" name="nivel" value="1">

                    <!--OWNER ALBUM --> 
                    <input type="hidden" name="owner_album_id" value="<?php echo e($album->id); ?>">

                    <hr>
                    <button type="submit" class="btn btn-success" id="enviar">Cadastrar</button>
                    <a href="<?php echo e(route('sub-albums.show', $album->id)); ?>" class="btn btn-link">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Include the Quill library -->
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

<!-- Initialize Quill editor -->
<script>
    var toolbarOptions = [
        [{ 'header': 1 }, { 'header': 2 }],     
        [{ 'align': [] }],
    ];

    var quill = new Quill('#editor', {
        modules: {
            toolbar: toolbarOptions
        },
        theme: 'snow'
    });

    document.querySelector('#enviar').addEventListener('click', function() {
        const textEditor = document.querySelector('.ql-editor');
        const hiddenInput = document.querySelector('#conteudo');
        hiddenInput.setAttribute('value', textEditor.innerHTML);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/sub-albums/create.blade.php ENDPATH**/ ?>