

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>DashBoard</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header">
                        Prestação de Contas
                    </div>
                    <div class="card-body">
                        <h1><?php echo e($contas); ?></h1>
                        <p class="card-text">Cadastrada(s).</p>
                        <a href="<?php echo e(route('contas.index')); ?>" class="btn btn-primary">Acesse</a>
                    </div>
                  </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header">
                        Imagens
                    </div>
                    <div class="card-body">
                        <h1><?php echo e($imagens); ?></h1>
                        <p class="card-text">Cadastrada(s).</p>
                        <a href="<?php echo e(route('albums.index')); ?>" class="btn btn-primary">Acesse</a>
                    </div>
                  </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header">
                        Avisos
                    </div>
                    <div class="card-body">
                        <h1><?php echo e($avisos); ?></h1>
                        <p class="card-text">Cadastrado(s).</p>
                        <a href="<?php echo e(route('avisos.index')); ?>" class="btn btn-primary">Acesse</a>
                    </div>
                  </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/admin/index.blade.php ENDPATH**/ ?>