<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<h1>Contato: </h1>
<h2>Nome: <?php echo e($dados->nome); ?></h2>
<h2>Email: <?php echo e($dados->email); ?></h2>
<h2>Mensagem: <?php echo e($dados->mensagem); ?></h2><?php /**PATH /home/defaultwebsite/resources/views/mail/index.blade.php ENDPATH**/ ?>