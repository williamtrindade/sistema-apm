<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="columns">
            <div class="column is-12-desktop is-12-mobile">   
                <h1 class="title is-4 ">Prestação de Contas</h1>
                <a href="<?php echo e(route('contas.create')); ?>" class="btn btn-primary" style="margin-bottom:2%;">Cadastrar Prestação de Contas</a>
                <div class="box">
                    <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($contas->count() > 0): ?>
                       
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Nome do Arquivo</th>
                                    <th>Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(Carbon\Carbon::parse($conta->data)->format('d/m/Y ')); ?></td>
                                    <th><a href="<?php echo e(asset('storage/contas/'.$conta->arquivo)); ?>"><?php echo e($conta->arquivo); ?></a></th>
                                    <th>
                                        <form method="POST" action="<?php echo e(route('contas.destroy', $conta)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                        </form>  
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>  
                        <?php echo e($contas->links()); ?>

                    <?php else: ?>
                        <div class="alert alert-success" role="alert">
                            Sem Prestação de contas!
                        </div>
                    <?php endif; ?>                 
                  
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/contas/index.blade.php ENDPATH**/ ?>