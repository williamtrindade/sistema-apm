<?php $__env->startSection('content'); ?>
    <?php if(isset($years)): ?>
        <div class="container">
            <h1>Prestação de Contas</h1>
            <h2 class="mt-1 mb-2">Anos</h2>
            <div class="row">
                <div class="col-sm-4 mb-5">
                    <ul>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a style="font-size:150%;" href="<?php echo e(route('home.contas.months', $year)); ?>">
                                Ano de <?php echo e($year); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>     
    <?php endif; ?>

    <?php if(isset($months)): ?>
        <div class="container">
            <h1>Prestação de Contas</h1>
            <a href=" <?php echo e(route('home.contas.index')); ?>" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Voltar</a>
            <h3 class="mt-1 mb-2">Ano de <?php echo e($year); ?></h3>
            <div class="row">
                <div class="col-md-12">
                    <ul>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a style="font-size:150%;" href="<?php echo e(route('home.contas.show', [$month, $year])); ?>" >
                                Mês <?php echo e($month); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>     
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/public/contas/index.blade.php ENDPATH**/ ?>