<?php $__env->startSection('content'); ?>
<div class="container">      
    <div class="row" >
        <div class="col-md-12" id="contato">
            <div class=" p-3">        
                <h1>Funcionários</h1>
                <hr>
                <div>
                    <p>Auxiliares Administrativas:</p>
                    <ul>      
                        <li>Patrícia de Miranda Rossi</li>
                        <li>Jane Dias Torri</li>
                    </ul>
                    <p>Assistente Social:</p>
                    <ul>      
                        <li>Marta Kirchoff Fagundes de Farias</li>
                    </ul>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/public/funcionarios/index.blade.php ENDPATH**/ ?>