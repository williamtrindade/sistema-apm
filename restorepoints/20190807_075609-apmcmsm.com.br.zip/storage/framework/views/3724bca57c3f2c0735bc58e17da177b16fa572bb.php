<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="columns">
            <div class="column is-12-desktop is-12-mobile">
                <h1 class="title is-4">Cadastro de Prestação de Contas </h1>
                <div class="box">
                    <form action="<?php echo e(route('contas.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="arquivo">Arquivo</span>
                            </div>
                            <div class="custom-file">
                                <input required name="arquivo" type="file" class="custom-file-input" id="arquivo" aria-describedby="arquivo">
                                <label class="custom-file-label" for="arquivo">Escolha um arquivo</label>
                            </div>
                            <?php if ($errors->has('arquivo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('arquivo'); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            
                        </div>
                        <div class="form-group">
                            <label for="data">Data</label>
                            <div>
                                <input name="data" class="form-control" type="date"  id="data">
                            </div>
                        </div>
                        <?php if ($errors->has('data')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('data'); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <button type="submit" class="btn btn-success">Cadastrar</button>
                        <a href="<?php echo e(route('contas.index')); ?>" class="btn btn-link">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/contas/create.blade.php ENDPATH**/ ?>