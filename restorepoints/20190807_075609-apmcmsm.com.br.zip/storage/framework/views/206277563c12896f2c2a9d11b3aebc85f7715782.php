
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet"> 
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">
                <img src="<?php echo e(asset('img/logoe.png')); ?>" width="25" height="30" alt="Logotipo APM">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="nav navbar-nav mr-auto">
                
                </ul>
                <ul class="nav justify-content-center navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('avisos.index')); ?>">Avisos</a>
                    </li>
                    <li class="nav-item">
                        <a  class="nav-link active" href=" <?php echo e(route('contas.index')); ?>">Prestação de Contas</a>
                    </li>
                    <li class="nav-item">
                        <a  class="nav-link active" href="<?php echo e(route('albums.index')); ?>" >Galeria de Imagens</a>
                    </li>
                </ul>
                <?php if(auth()->guard()->guest()): ?>
                            
                <?php else: ?>
                <ul class="nav justify-content-end">
                    <li class="nav-item dropdown">
                        <a style="color:white;" class="nav-link dropdown-toggle" href="<?php echo e(route('admin.index')); ?>" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                Sair
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a type="button" class="btn btn-success" href="<?php echo e(route('home.index')); ?>">Voltar Ao Site</a>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>   
    </main>
        
    </div>

</body>
<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</html>
<?php /**PATH /home/defaultwebsite/resources/views/layouts/admin.blade.php ENDPATH**/ ?>