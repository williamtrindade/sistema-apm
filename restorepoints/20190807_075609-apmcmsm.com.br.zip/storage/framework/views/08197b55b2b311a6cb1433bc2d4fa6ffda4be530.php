<div class="row">
		<div class="row">
            <?php $__currentLoopData = $imagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-xs-6  img-fluid">
                    <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="" data-image="<?php echo e(asset('storage/imagens/'.$imagem->imagem)); ?>" data-target="#image-gallery">
                        <img class="img-thumbnail " src="<?php echo e(asset('storage/imagens/'.$imagem->imagem)); ?>" alt="Another alt text">
                    </a>
                    <form style="top:0;position:absolute" method="POST" action="<?php echo e(route('imagens.destroy', $imagem->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" style="top:0" type="submit"><i  class="fas fa-trash"></i> Apagar</button>
                    </form>  
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="image-gallery-title"></h4>
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <img id="image-gallery-image" class="img-responsive col-md-12" src="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary float-left" id="show-previous-image"><i class="fa fa-arrow-left"></i>
                        </button>

                        <button type="button" id="show-next-image" class="btn btn-secondary float-right"><i class="fa fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
	</div><?php /**PATH /home/defaultwebsite/resources/views/includes/galery.blade.php ENDPATH**/ ?>