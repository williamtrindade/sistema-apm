<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">  
            <h1>Galeria de Imagens</h1>
            <a href="<?php echo e(route('albums.create')); ?>" class="btn btn-primary" style="margin-bottom:2%;"><i class="fas fa-plus"></i> Criar Álbum</a>

            <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 shadow p-4"> 
            <?php if($albums->count() > 0): ?>
                <h4>Todos os Álbuns</h4>
                <table class="table  table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Nome do Álbum</th>
                            <th>Quantidade de Sub Álbuns</th>
                            <th  style="text-align: center;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($album->nome); ?></th>
                                <th><?php echo e($album->albums()->count()); ?></th>
                                <th style="text-align: right;">
                                    <a href="<?php echo e(route('sub-albums.show', $album->id)); ?>" class="btn btn-success">
                                        <i class="fas fa-eye"></i> Visualizar
                                    </a>  
                            
                                    <a href="<?php echo e(route('albums.edit', $album->id)); ?>" class="btn btn-primary">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>

                                    <form style="display: inline;" method="POST" action="<?php echo e(route('albums.destroy', $album->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
                                    </form>
    
                                </th>
                            </tr>
                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($albums->links()); ?>

            <?php else: ?>
                <div class="col-md-12">
                    <div class="alert alert-success" role="alert">
                        Você ainda não cadastrou Álbuns na galeria!
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/albums/index.blade.php ENDPATH**/ ?>