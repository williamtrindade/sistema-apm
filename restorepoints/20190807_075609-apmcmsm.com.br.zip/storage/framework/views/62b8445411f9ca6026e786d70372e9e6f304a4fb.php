<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>Galeria de Imagens</h1>
        <h4>Álbuns</h4>
        <?php if(isset($albums)): ?>
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                <li><h4><a href="<?php echo e(route('home.albuns.show', $album->id)); ?>"><?php echo e($album->nome); ?></a></h4></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/public/imagens/index.blade.php ENDPATH**/ ?>