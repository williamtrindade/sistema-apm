<?php if(session('status-success')): ?>
<div class="alert alert-success" role="alert">
<?php echo e(session('status-success')); ?>

</div>
<?php endif; ?>

<?php if(session('status-danger')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('status-danger')); ?>

</div>
<?php endif; ?>


<?php /**PATH /home/defaultwebsite/resources/views/includes/notification.blade.php ENDPATH**/ ?>