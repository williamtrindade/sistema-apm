<?php $__env->startSection('content'); ?>
<style>
    .a-img{
        font-style: none;
        color: #000;
        text-decoration: none;
        border:#000 1px solid;
        height: 170px;
    }

    .a-img:hover {
        color: #000;
    }
</style>
<div class="container">
    <h1>Galeria de Imagens</h1>

    <a href="<?php echo e(route('albums.index')); ?>" class="btn btn-secondary" style="margin-bottom:2%;"><i class="fas fa-arrow-left"></i> Voltar</a><br>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('albums.index')); ?>">Albums</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($album->nome); ?></li>
        </ol>
    </nav>
    <a href="<?php echo e(route('sub-albums.create',  $album->id )); ?>" class="btn btn-primary" style="margin-bottom:2%;"><i class="fas fa-plus"></i> Criar Sub Álbum</a>
    <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
       
    </table>

    <div class="row">
        <?php if($album->albums()->count() > 0): ?>
            <div class="col-md-12">
                <h4>Álbuns do álbum <span style="color:#000;"><?php echo e($album->nome); ?></span></h4>
            </div>
            <table class="table  table-striped m-3">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Nome do Álbum</th>
                        <th>Quantidade de Imagens</th>
                        <th  style="text-align: center;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $album->albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($album->nome); ?></th>
                        <th><?php echo e($album->imagens->count()); ?></th>
                        <th style="text-align: right;">
                            <a href="<?php echo e(route('imagens.show', $album->id)); ?>" class="btn btn-success">
                                <i class="fas fa-eye"></i> Visualizar Imagens
                            </a>  
                    
                            <a href="<?php echo e(route('albums.edit', $album->id)); ?>" class="btn btn-primary">
                                <i class="fas fa-edit"></i> Editar
                            </a>
    
                            <form style="display: inline;" method="POST" action="<?php echo e(route('albums.destroy', $album->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
                            </form>
    
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    Você ainda não cadastrou Álbuns nesse Álbum
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/sub-albums/show.blade.php ENDPATH**/ ?>