<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <h1>Avisos</h1>
                <a href="<?php echo e(route('avisos.create')); ?>" class="btn btn-primary" style="margin-bottom:2%;">Cadastrar Aviso</a>
             
                <div>
                    <?php if(count($avisos) > 0): ?>
                        <table class="table is-fullwidth">
                            <thead>
                                <tr>
                                    <th>Título</th>
                                    <th>Conteúdo</th>
                                    <th>Data / Hora</th> 
                                    <th>Ação</th>   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $avisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aviso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($aviso->titulo); ?></td>
                                        <td>...</td>
                                        <td><?php echo e($aviso->created_at); ?></td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('avisos.destroy', $aviso->id)); ?>">
                                                <a href="<?php echo e(route('avisos.edit', $aviso->id)); ?>" class="btn btn-primary"><i class="fas fa-edit"></i> Editar</a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Excluir</button>
                                            </form>  
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($avisos->links()); ?>

                    <?php else: ?> 
                        <div class="alert alert-success" role="alert">
                        Você não cadastrou Avisos!
                        </div>
                    <?php endif; ?>
                   
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/avisos/index.blade.php ENDPATH**/ ?>