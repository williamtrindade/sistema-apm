<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Diretoria</h1>
        <img class="img-fluid" src="<?php echo e(asset('img/diretoria.png')); ?>"  alt="">
        <h1>Ex-Presidentes</h1>
        <img src="<?php echo e(asset('img/expresidentes.jpg')); ?>" alt="">
    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/public/diretoria/index.blade.php ENDPATH**/ ?>