<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-3">Avisos</h1>
    <ul class="list-unstyled">
        <?php $__currentLoopData = $avisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aviso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="media shadow p-3 mb-2">
                <div class="media-body">
                    <h3 class="mt-0 mb-1"><?php echo e($aviso->titulo); ?></h3>
                    <?php if($aviso->pdf): ?>
                        <?php if($aviso->conteudo): ?>
                            <?php echo $aviso->conteudo; ?>

                        <?php endif; ?>
                        <a href="<?php echo e(asset('storage/avisos/'.$aviso->pdf)); ?>">Ver Anexo do Aviso</a>
                    <?php else: ?>
                        <?php echo $aviso->conteudo; ?>

                    <?php endif; ?>
                    <hr>

                    <div class="row">
                        <div class="col-md-9"></div>
                        <div class="col-md-3"> Públicado em <?php echo e($aviso->created_at->format('d/m/Y')); ?></div>
                    </div>
                </div>
            </li>     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<script type="text/javascript">

    const imagens = document.querySelectorAll("img");
    imagens.forEach(imagem => {
        imagem.setAttribute('class', 'img-fluid');
        console.log(imagem);
    });
</script> 
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/public/avisos/index.blade.php ENDPATH**/ ?>