@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Diretoria</h1>
        <img class="img-fluid" src="{{ asset('img/diretoria.png') }}"  alt="">
        <h1>Ex-Presidentes</h1>
        <img src="{{ asset('img/expresidentes.jpg') }}" alt="">
    </div>
   
@endsection