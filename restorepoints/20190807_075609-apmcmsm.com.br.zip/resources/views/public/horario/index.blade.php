@extends('layouts.app')

@section('content')
<div class="container">


<div class="col-md-12">
        <div class="p-3">        
            <h1> Horário de Funcionamento ao Público externo</h1>
            <hr>
            <div>
                <p>Segunda a Quinta:</p>
                <ul>
                    <li>7h30min às 12h - 13h30min às 16h30min</li>
                </ul>
                <p>Sexta-feira:</p>
                <ul>
                    <li>7h30min às 12h</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
