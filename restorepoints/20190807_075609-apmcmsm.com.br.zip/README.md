# sistema-apm  
## Laravel 5.8  

## Dependências  
PHP >= 7.1.3   
BCMath PHP Extension  
Ctype PHP Extension  
JSON PHP Extension  
Mbstring PHP Extension  
OpenSSL PHP Extension  
PDO PHP Extension  
Tokenizer PHP Extension  
XML PHP Extension  
