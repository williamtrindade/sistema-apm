<?php

namespace TusPhp\Exception;

class FileException extends \RuntimeException
{
}
