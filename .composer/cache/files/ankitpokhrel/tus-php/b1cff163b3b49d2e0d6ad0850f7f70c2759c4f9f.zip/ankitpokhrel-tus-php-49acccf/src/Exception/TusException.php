<?php

namespace TusPhp\Exception;

class TusException extends \Exception
{
}
