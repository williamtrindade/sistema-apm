<?php

namespace TusPhp\Exception;

class ConnectionException extends \Exception
{
}
